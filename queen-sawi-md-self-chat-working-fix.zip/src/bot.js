import fs from 'fs';
import os from 'os';
import path from 'path';
import crypto from 'crypto';
import { execFile } from 'child_process';
import { promisify } from 'util';
import sharp from 'sharp';
import ffmpegPath from 'ffmpeg-static';
import youtubedl from 'youtube-dl-exec';
import QRCode from 'qrcode';
import Parser from 'rss-parser';
import { downloadContentFromMessage } from '@whiskeysockets/baileys';
import { getSettings, updateSettings } from './settings.js';
import config from '../config.js';
import { logEvent } from './db.js';

const execFileAsync = promisify(execFile);
const rss = new Parser();
const commandCooldown = new Map();

function text(m) {
  return m?.conversation || m?.extendedTextMessage?.text || m?.imageMessage?.caption || m?.videoMessage?.caption || m?.buttonsResponseMessage?.selectedButtonId || m?.listResponseMessage?.singleSelectReply?.selectedRowId || '';
}
function baseJid(jid='') { return String(jid).split(':')[0]; }
function cleanPhone(jid='') { return baseJid(jid).replace(/@.+$/, ''); }
function senderJid(msg, remoteJid) { return msg.key?.participant || (msg.key?.fromMe ? msg.key?.remoteJid : remoteJid); }
function isGroup(jid='') { return jid.endsWith('@g.us'); }
function runtime(ms) { const s=Math.floor(ms/1000); const d=Math.floor(s/86400), h=Math.floor((s%86400)/3600), m=Math.floor((s%3600)/60), sec=s%60; return `${d}d ${h}h ${m}m ${sec}s`; }
function fmtBytes(n){ if(!n) return '0 B'; const u=['B','KB','MB','GB']; const i=Math.min(Math.floor(Math.log(n)/Math.log(1024)),u.length-1); return `${(n/1024**i).toFixed(i?2:0)} ${u[i]}`; }
function quoted(msg){ return msg.message?.extendedTextMessage?.contextInfo?.quotedMessage || null; }
function quotedType(msg){ const q=quoted(msg); if(!q) return null; if(q.imageMessage)return'image'; if(q.videoMessage)return'video'; if(q.stickerMessage)return'sticker'; if(q.audioMessage)return'audio'; return null; }
async function mediaBuffer(message, type){ const stream=await downloadContentFromMessage(message, type); const chunks=[]; for await(const c of stream) chunks.push(c); return Buffer.concat(chunks); }
async function quotedBuffer(msg){ const q=quoted(msg); if(!q) return null; const t=quotedType(msg); if(!t)return null; const key=t+'Message'; return mediaBuffer(q[key], t); }
async function reply(s,jid,text,opts={}){ await s.sendMessage(jid,{text,...opts}); }
async function react(s,jid,key,emoji){ try{await s.sendMessage(jid,{react:{text:emoji,key}})}catch{} }
async function groupInfo(s,jid){ return s.groupMetadata(jid); }
function parseMention(text){ return [...text.matchAll(/@([0-9]{6,16})/g)].map(m=>`${m[1]}@s.whatsapp.net`); }
function hasUrl(t){ return /https?:\/\/[^\s]+/i.test(t); }
async function admins(s,jid){ const g=await groupInfo(s,jid); return g.participants.filter(p=>p.admin).map(p=>p.id); }
async function isAdmin(s,jid,user){ if(!isGroup(jid))return false; return (await admins(s,jid)).some(x=>baseJid(x)===baseJid(user)); }
async function botIsAdmin(s,jid){ return isAdmin(s,jid,baseJid(s.user?.id)); }
async function ensureAdmin(s,jid,user){ if(!isGroup(jid)) return 'This command is only for groups.'; if(!(await isAdmin(s,jid,user))) return 'Admin permission required.'; if(!(await botIsAdmin(s,jid))) return 'Bot must be a group admin first.'; return null; }
async function tempFile(ext){ const p=path.join(os.tmpdir(),`qs-${crypto.randomBytes(8).toString('hex')}${ext}`); return p; }

async function makeSticker(buf, inputExt='.jpg'){
  const input=await tempFile(inputExt), output=await tempFile('.webp'); fs.writeFileSync(input,buf);
  try{ await execFileAsync(ffmpegPath,['-y','-i',input,'-vf','scale=512:512:force_original_aspect_ratio=decrease,pad=512:512:(ow-iw)/2:(oh-ih)/2:color=0x00000000','-vcodec','libwebp','-lossless','0','-q:v','55','-loop','0','-an',output]); return fs.readFileSync(output); }
  finally{for(const p of [input,output])try{fs.unlinkSync(p)}catch{}}
}
async function stickerToImage(buf){ return sharp(buf).png().toBuffer(); }
async function runYtdlp(url,audio=false){
  const out=await tempFile(audio?'.mp3':'.mp4');
  try{
    const args=audio?{extractAudio:true,audioFormat:'mp3',output:out,noPlaylist:true,quiet:true}:{format:'bv*[ext=mp4]+ba[ext=m4a]/b[ext=mp4]/b',mergeOutputFormat:'mp4',output:out,noPlaylist:true,quiet:true};
    await youtubedl(url,args);
    return {path:out,buffer:fs.readFileSync(out)};
  } catch(e){ try{fs.unlinkSync(out)}catch{}; throw new Error(e.stderr||e.message||'Downloader failed'); }
}
async function ai(prompt){
  const a=config.apis?.ai||{}; if(!a.apiKey) throw new Error('AI API key is not configured in config.js');
  const r=await fetch(a.baseUrl||'https://api.groq.com/openai/v1/chat/completions',{method:'POST',headers:{'content-type':'application/json',authorization:`Bearer ${a.apiKey}`},body:JSON.stringify({model:a.model||'llama-3.3-70b-versatile',messages:[{role:'user',content:prompt}],temperature:.7})});
  const j=await r.json(); if(!r.ok)throw new Error(j?.error?.message||'AI request failed'); return j.choices?.[0]?.message?.content||'No response';
}
async function translate(q,to='en'){
  const url=`https://api.mymemory.translated.net/get?q=${encodeURIComponent(q)}&langpair=auto|${encodeURIComponent(to)}`; const j=await (await fetch(url)).json(); return j?.responseData?.translatedText||'Translation failed';
}
async function weather(city){ const r=await fetch(`https://wttr.in/${encodeURIComponent(city)}?format=j1`,{headers:{'user-agent':'QueenSawiMD/4'}}); if(!r.ok)throw new Error('Weather service unavailable'); const j=await r.json(); const c=j.current_condition?.[0]; return `Weather: ${city}\nCondition: ${c.weatherDesc?.[0]?.value}\nTemperature: ${c.temp_C}°C\nFeels like: ${c.FeelsLikeC}°C\nHumidity: ${c.humidity}%\nWind: ${c.windspeedKmph} km/h` }
async function wiki(q){ const r=await fetch(`https://en.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(q.replace(/ /g,'_'))}`); const j=await r.json(); if(!r.ok)throw new Error(j?.detail||'Not found'); return `${j.title}\n\n${j.extract||'No summary.'}\n\n${j.content_urls?.desktop?.page||''}`; }
async function define(q){ const r=await fetch(`https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(q)}`); const j=await r.json(); if(!r.ok)throw new Error('Word not found'); const x=j[0]; return `${x.word}\n\n${x.meanings?.slice(0,2).map(m=>`${m.partOfSpeech}: ${m.definitions?.[0]?.definition}`).join('\n')||'No definition.'}`; }

export function attachBot(entry){
  const s=entry.sock; if(!s)return; if(entry.botAttachedTo===s)return; entry.botAttachedTo=s;

  s.ev.on('group-participants.update', async ({id,participants,action})=>{
    try{
      const st=getSettings(entry.id); if(!st.welcome)return;
      const g=await s.groupMetadata(id); const names=participants.map(p=>`@${cleanPhone(p)}`).join(', ');
      if(action==='add') await s.sendMessage(id,{text:`Welcome ${names}\nWelcome to ${g.subject}!`,mentions:participants});
      if(action==='remove'&&st.goodbye) await s.sendMessage(id,{text:`Goodbye ${names}`,mentions:participants});
    }catch(e){console.error(`[BOT:${entry.id}] participant update`,e.message)}
  });

  s.ev.on('messages.upsert', async ({messages})=>{
    for(const msg of messages){
      if(!msg.message)continue;
      const remoteJid=msg.key?.remoteJid||'';
      const remoteAlt=msg.key?.remoteJidAlt||msg.key?.participantAlt||'';
      if(!remoteJid||remoteJid==='status@broadcast')continue;
      const selfIds=[s.user?.id,s.user?.lid,remoteAlt].filter(Boolean).map(baseJid);
      const self=Boolean(msg.key?.fromMe) && (
        selfIds.includes(baseJid(remoteJid)) ||
        selfIds.includes(baseJid(remoteAlt)) ||
        baseJid(remoteJid)===baseJid(s.user?.id||'')
      );
      if(msg.key?.fromMe&&!self)continue;
      const t=text(msg.message).trim(); if(!t)continue;
      const st=getSettings(entry.id); const sender=senderJid(msg,remoteJid); const prefix=st.prefix||config.prefix||'.';
      const ownerOfMessage=config.ownerNumbers?.some(n=>baseJid(String(n))===baseJid(cleanPhone(sender)));
      if(st.publicMode===false&&!self&&!ownerOfMessage)continue;
      if(st.antiLink&&!self&&hasUrl(t)&&isGroup(remoteJid)){
        try{ if(await botIsAdmin(s,remoteJid)){await s.sendMessage(remoteJid,{delete:msg.key}); await reply(s,remoteJid,'Link removed by anti-link.');} }catch{}
      }
      if(!t.startsWith(prefix))continue;
      const parts=t.slice(prefix.length).trim().split(/\s+/); const cmd=(parts.shift()||'').toLowerCase(); const arg=parts.join(' ').trim();
      const cooldownKey=`${entry.id}:${sender}:${cmd}`; const now=Date.now(); if((commandCooldown.get(cooldownKey)||0)>now)continue; commandCooldown.set(cooldownKey,now+800);
      try{
        if(st.autoRead&&!self)await s.readMessages([msg.key]);
        if(st.autoTyping)await s.sendPresenceUpdate('composing',remoteJid).catch(()=>{});
        if(cmd==='ping') await reply(s,remoteJid,`Pong!\n${Date.now()-Number(msg.messageTimestamp||Math.floor(Date.now()/1000))*1000} ms`);
        else if(cmd==='alive'||cmd==='runtime') await reply(s,remoteJid,`${config.botName||config.name}\nStatus: Connected\nUptime: ${runtime(Date.now()-entry.startedAt)}\nNode: ${process.version}\nRAM: ${fmtBytes(process.memoryUsage().rss)}`);
        else if(cmd==='about') await reply(s,remoteJid,`${config.name}\n${config.subtitle}\n\nReal multi-session WhatsApp bot platform.`);
        else if(cmd==='owner') await reply(s,remoteJid,`Owner: ${(config.ownerNumbers||[]).join(', ')||'Set ownerNumbers in config.js'}`);
        else if(cmd==='menu'||cmd==='help') await reply(s,remoteJid,`${config.name}\n\nGENERAL\n${prefix}alive ${prefix}ping ${prefix}about ${prefix}owner ${prefix}status\n\nMEDIA\n${prefix}sticker ${prefix}toimg ${prefix}yt ${prefix}yta ${prefix}tt ${prefix}ig\n\nTOOLS\n${prefix}qr ${prefix}short ${prefix}translate ${prefix}weather ${prefix}wiki ${prefix}define ${prefix}ai\n\nGROUP\n${prefix}tagall ${prefix}hidetag ${prefix}admins ${prefix}groupinfo ${prefix}kick ${prefix}add ${prefix}promote ${prefix}demote ${prefix}mute ${prefix}unmute\n\nOWNER\n${prefix}settings ${prefix}setprefix ${prefix}mode`);
        else if(cmd==='status') await reply(s,remoteJid,`WhatsApp: ${entry.status}\nPhone: ${entry.phone||'unknown'}\nSession: ${entry.id}\nAuto read: ${st.autoRead}\nAuto typing: ${st.autoTyping}`);
        else if(cmd==='settings') { if(!self&&!ownerOfMessage&&!isGroup(remoteJid))return; await reply(s,remoteJid,JSON.stringify(st,null,2)); }
        else if(cmd==='setprefix') { const ok=config.ownerNumbers?.some(n=>baseJid(n)===baseJid(cleanPhone(sender))); if(!ok){ await reply(s,remoteJid,'Owner only.'); } else { const p=arg.trim().slice(0,3); if(!p)await reply(s,remoteJid,'Usage: .setprefix !'); else { updateSettings(entry.id,{prefix:p}); await reply(s,remoteJid,`Prefix changed to: ${p}`); } } }
        else if(cmd==='mode') { if(!self&&!ownerOfMessage&&!isGroup(remoteJid))return; if(!arg||!['button','text'].includes(arg)) await reply(s,remoteJid,`Current mode: ${st.mode}\nUsage: ${prefix}mode button|text`); else { updateSettings(entry.id,{mode:arg}); await reply(s,remoteJid,`Mode set to ${arg}`); } }
        else if(cmd==='setting') { if(!self&&!ownerOfMessage&&!isGroup(remoteJid))return; if(!arg.includes(' ')) return await reply(s,remoteJid,'Usage: .setting <key> <on|off>'); const [k,v]=arg.split(/\s+/,2); const keys=['autoRead','autoTyping','autoPresence','welcome','goodbye','antiLink','antiSpam','antiBadword','publicMode','replyToCommands']; if(!keys.includes(k))return await reply(s,remoteJid,`Allowed: ${keys.join(', ')}`); updateSettings(entry.id,{[k]:['on','true','1'].includes(v.toLowerCase())}); await reply(s,remoteJid,`${k}: ${['on','true','1'].includes(v.toLowerCase())?'ON':'OFF'}`); }
        else if(cmd==='sticker'||cmd==='s') { const typ=quotedType(msg); if(!typ||!['image','video'].includes(typ)) return await reply(s,remoteJid,'Reply to an image or short video.'); const b=await quotedBuffer(msg); const webp=await makeSticker(b,typ==='video'?'.mp4':'.jpg'); await s.sendMessage(remoteJid,{sticker:webp},{quoted:msg}); }
        else if(cmd==='toimg') { if(quotedType(msg)!=='sticker')return await reply(s,remoteJid,'Reply to a sticker.'); const b=await quotedBuffer(msg); await s.sendMessage(remoteJid,{image:await stickerToImage(b),caption:'Converted by Queen Sawi MD'},{quoted:msg}); }
        else if(cmd==='tomp3') { if(quotedType(msg)!=='video'&&quotedType(msg)!=='audio')return await reply(s,remoteJid,'Reply to audio/video.'); const b=await quotedBuffer(msg); const input=await tempFile(quotedType(msg)==='video'?'.mp4':'.ogg'),out=await tempFile('.mp3'); fs.writeFileSync(input,b); try{await execFileAsync(ffmpegPath,['-y','-i',input,'-vn','-codec:a','libmp3lame','-b:a','128k',out]); await s.sendMessage(remoteJid,{audio:fs.readFileSync(out),mimetype:'audio/mpeg'},{quoted:msg});}finally{for(const p of[input,out])try{fs.unlinkSync(p)}catch{}} }
        else if(['yt','youtube','yta','ytdl','tt','tiktok','ig','instagram'].includes(cmd)){ if(!arg)return await reply(s,remoteJid,`Usage: ${prefix}${cmd} https://...`); const audio=['yta'].includes(cmd); const r=await runYtdlp(arg,audio); try{ if(r.buffer.length>70*1024*1024)return await reply(s,remoteJid,'Media is too large for this bot.'); if(audio)await s.sendMessage(remoteJid,{audio:r.buffer,mimetype:'audio/mpeg',fileName:'queen-sawi.mp3'},{quoted:msg}); else await s.sendMessage(remoteJid,{video:r.buffer,caption:'Downloaded by Queen Sawi MD',mimetype:'video/mp4',fileName:'queen-sawi.mp4'},{quoted:msg}); }finally{try{fs.unlinkSync(r.path)}catch{}} }
        else if(cmd==='qr') { if(!arg)return await reply(s,remoteJid,`Usage: ${prefix}qr text`); await s.sendMessage(remoteJid,{image:await QRCode.toBuffer(arg),caption:'QR generated by Queen Sawi MD'},{quoted:msg}); }
        else if(cmd==='short') { if(!/^https?:\/\//i.test(arg))return await reply(s,remoteJid,'Usage: .short https://example.com'); const r=await fetch(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(arg)}`); await reply(s,remoteJid,await r.text()); }
        else if(cmd==='translate'||cmd==='tr') { if(!arg)return await reply(s,remoteJid,`Usage: ${prefix}translate <text> [language]`); const m=arg.match(/^(.*)\s+([a-z]{2})$/i); await reply(s,remoteJid,await translate(m?m[1]:arg,m?m[2]:'en')); }
        else if(cmd==='weather') { if(!arg)return await reply(s,remoteJid,'Usage: .weather Colombo'); await reply(s,remoteJid,await weather(arg)); }
        else if(cmd==='wiki') { if(!arg)return await reply(s,remoteJid,'Usage: .wiki topic'); await reply(s,remoteJid,await wiki(arg)); }
        else if(cmd==='define') { if(!arg)return await reply(s,remoteJid,'Usage: .define word'); await reply(s,remoteJid,await define(arg)); }
        else if(cmd==='ai'||cmd==='ask') { if(!arg)return await reply(s,remoteJid,'Usage: .ai your question'); await reply(s,remoteJid,await ai(arg)); }
        else if(isGroup(remoteJid)&&['tagall','hidetag','admins','groupinfo','kick','add','promote','demote','mute','unmute'].includes(cmd)){
          const denied=await ensureAdmin(s,remoteJid,sender); if(denied)return await reply(s,remoteJid,denied); const g=await groupInfo(s,remoteJid);
          if(cmd==='groupinfo')return await reply(s,remoteJid,`Group: ${g.subject}\nMembers: ${g.participants.length}\nAdmins: ${g.participants.filter(p=>p.admin).length}`);
          if(cmd==='admins')return await reply(s,remoteJid,`Admins:\n${g.participants.filter(p=>p.admin).map(p=>`@${cleanPhone(p.id)}`).join('\n')}`,{mentions:g.participants.filter(p=>p.admin).map(p=>p.id)});
          if(cmd==='tagall'||cmd==='hidetag'){const mentions=g.participants.map(p=>p.id); const body=arg||g.participants.map(p=>`@${cleanPhone(p.id)}`).join(' '); return await s.sendMessage(remoteJid,{text:body,mentions});}
          let targets=parseMention(t); if(!targets.length&&arg)targets=arg.split(/[ ,]+/).filter(x=>/^\d{6,16}$/.test(x)).map(x=>`${x}@s.whatsapp.net`);
          if(['kick','add','promote','demote'].includes(cmd)&&!targets.length)return await reply(s,remoteJid,`Usage: ${prefix}${cmd} 947XXXXXXXX`);
          if(cmd==='kick')await s.groupParticipantsUpdate(remoteJid,targets,'remove');
          if(cmd==='add')await s.groupParticipantsUpdate(remoteJid,targets,'add');
          if(cmd==='promote')await s.groupParticipantsUpdate(remoteJid,targets,'promote');
          if(cmd==='demote')await s.groupParticipantsUpdate(remoteJid,targets,'demote');
          if(cmd==='mute')await s.groupSettingUpdate(remoteJid,'announcement');
          if(cmd==='unmute')await s.groupSettingUpdate(remoteJid,'not_announcement');
          await reply(s,remoteJid,`${cmd} completed.`);
        }
      }catch(e){ console.error(`[BOT:${entry.id}] ${cmd}:`,e.message); await reply(s,remoteJid,`Error: ${String(e.message).slice(0,700)}`); await logEvent(entry.owner,entry.id,'command_error',e.message,{cmd}); }
      finally{ if(st.autoTyping)await s.sendPresenceUpdate('paused',remoteJid).catch(()=>{}); }
    }
  });
}
