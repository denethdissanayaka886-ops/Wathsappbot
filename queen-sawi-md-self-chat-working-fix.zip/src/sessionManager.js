import fs from "fs";
import path from "path";
import pino from "pino";
import makeWASocket, {
  useMultiFileAuthState,
  DisconnectReason,
  Browsers,
  fetchLatestBaileysVersion,
  fetchLatestWaWebVersion
} from "@whiskeysockets/baileys";
import { Boom } from "@hapi/boom";
import config from "../config.js";
import { Session, logEvent } from "./db.js";
import { attachBot } from "./bot.js";

const sessions = new Map();
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

fs.mkdirSync(config.storage.sessionsDir, { recursive: true });

function statusCode(error) {
  return new Boom(error)?.output?.statusCode;
}

async function saveSession(entry, extra = {}) {
  try {
    await Session.findOneAndUpdate(
      { sessionId: entry.id },
      {
        sessionId: entry.id,
        owner: entry.owner || null,
        phone: entry.phone || "",
        status: entry.status || "starting",
        ...extra
      },
      { upsert: true }
    );
  } catch (error) {
    console.error(`[SESSION:${entry.id}] DB update failed:`, error.message);
  }
}

async function issuePairingCode(entry) {
  if (!entry.phone || entry.pairingCode || entry.pairingRequested) return;
  if (!entry.sock || entry.sock.authState?.creds?.registered) return;

  entry.pairingRequested = true;

  try {
    // Wait until Baileys has emitted a QR/connecting state. Calling the
    // pairing endpoint too early can produce 428 Connection Closed.
    await sleep(2500);

    if (!entry.sock || entry.sock.authState?.creds?.registered) {
      entry.pairingRequested = false;
      return;
    }

    const code = await entry.sock.requestPairingCode(entry.phone);
    entry.pairingCode = code;
    entry.status = "pairing";
    entry.error = null;

    await saveSession(entry);
    console.log(`[PAIR:${entry.id}] Pairing code generated`);
  } catch (error) {
    entry.pairingRequested = false;
    entry.error = error?.message || "Pairing code request failed";

    const code = statusCode(error);
    if (code === 428 || code === 408 || code === 515) {
      entry.status = "reconnecting";
    } else {
      entry.status = "error";
    }

    await saveSession(entry);
    console.error(`[PAIR:${entry.id}] ${entry.error}`);

    // If the socket is still alive, give it another chance.
    if (entry.sock && !entry.sock.authState?.creds?.registered) {
      setTimeout(() => {
        if (sessions.get(entry.id) === entry && entry.status !== "connected") {
          issuePairingCode(entry).catch(() => {});
        }
      }, 2500);
    }
  }
}

export async function startSession(id, phone = null, owner = null) {
  const existing = sessions.get(id);
  if (existing) {
    if (phone) existing.phone = phone;
    if (owner) existing.owner = owner;
    return existing;
  }

  const dir = path.join(config.storage.sessionsDir, id);
  fs.mkdirSync(dir, { recursive: true });

  const { state, saveCreds } = await useMultiFileAuthState(dir);

  const entry = {
    id,
    phone: phone || null,
    owner: owner || null,
    status: state.creds.registered ? "connecting" : "starting",
    pairingCode: null,
    pairingRequested: false,
    error: null,
    sock: null,
    startedAt: Date.now(),
    shouldReconnect: true,
    attachBot: null
  };

  sessions.set(id, entry);

  let version;
  try {
    // fetchLatestBaileysVersion() can lag behind the live WhatsApp Web
    // revision. Prefer the authoritative version served by WhatsApp itself.
    const live = await fetchLatestWaWebVersion();
    version = Array.isArray(live?.version) ? live.version : null;
    if (version) {
      console.log(`[SESSION:${id}] WA Web version ${version.join('.')} (live)`);
    }
  } catch (error) {
    console.warn(`[SESSION:${id}] Live WA version fetch failed: ${error.message}`);
  }

  if (!version) {
    try {
      const fallback = await fetchLatestBaileysVersion();
      version = fallback?.version;
      if (version) console.warn(`[SESSION:${id}] Using Baileys fallback version ${version.join('.')}`);
    } catch (error) {
      console.warn(`[SESSION:${id}] Could not fetch fallback WA version; using library default`);
    }
  }

  const sock = makeWASocket({
    ...(version ? { version } : {}),
    auth: state,
    logger: pino({ level: "silent" }),
    printQRInTerminal: false,
    // Use a canonical browser descriptor. Custom labels have caused
    // WhatsApp to issue pairing codes that are rejected as dead codes.
    browser: Browsers.macOS("Chrome"),
    markOnlineOnConnect: true,
    emitOwnEvents: true,
    connectTimeoutMs: 60000,
    defaultQueryTimeoutMs: 60000,
    syncFullHistory: false
  });

  entry.sock = sock;
  sock.ev.on("creds.update", saveCreds);

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect, qr } = update;

    if (connection === "connecting") {
      entry.status = state.creds.registered ? "reconnecting" : "connecting";
      entry.error = null;
      await saveSession(entry);

      // Give the socket a moment to finish the Noise/registration handshake.
      if (!state.creds.registered && entry.phone) {
        setTimeout(() => {
          if (sessions.get(id) === entry && !entry.pairingCode && !entry.pairingRequested) {
            issuePairingCode(entry).catch(() => {});
          }
        }, 3000);
      }
    }

    // Official pairing-code flow: request only after the QR/registration
    // trigger is emitted, not immediately after socket creation.
    if (qr && !state.creds.registered && entry.phone) {
      issuePairingCode(entry).catch(() => {});
    }

    if (connection === "open") {
      entry.status = "connected";
      entry.pairingCode = null;
      entry.pairingRequested = false;
      entry.error = null;

      await saveSession(entry, { lastConnected: new Date(), firstConnectedAt: entry.firstConnectedAt || new Date() });
      await logEvent(entry.owner, id, "connected", "WhatsApp connected");
      console.log(`[SESSION:${id}] Connected`);
    }

    if (connection === "close") {
      const code = statusCode(lastDisconnect?.error);
      const terminal =
        code === DisconnectReason.loggedOut ||
        code === DisconnectReason.connectionReplaced;

      entry.status = terminal ? "logged_out" : "reconnecting";
      entry.error = terminal ? "WhatsApp session ended" : `Connection closed (${code || "unknown"})`;

      await saveSession(entry);

      if (!terminal && entry.shouldReconnect && sessions.get(id) === entry) {
        sessions.delete(id);

        setTimeout(() => {
          startSession(id, entry.phone, entry.owner)
            .then((next) => {
              next.reconnected = true;
              next.attachBot = attachBot;
              attachBot(next);
            })
            .catch((error) => {
              console.error(`[SESSION:${id}] Reconnect failed:`, error.message);
            });
        }, code === 515 ? 500 : 2500);
      } else if (terminal) {
        await logEvent(entry.owner, id, "logout", entry.error);
      }
    }
  });

  await saveSession(entry);
  return entry;
}

export async function requestPairingCode(id, phone) {
  let entry = sessions.get(id);

  if (!entry) {
    entry = await startSession(id, phone);
  }

  if (entry.pairingCode) return entry.pairingCode;

  if (phone) entry.phone = phone;

  const deadline = Date.now() + 20000;

  while (Date.now() < deadline) {
    if (entry.pairingCode) return entry.pairingCode;

    // A transient 428/515 can replace the socket. Follow the new entry.
    const current = sessions.get(id);
    if (current && current !== entry) {
      entry = current;
      if (entry.pairingCode) return entry.pairingCode;
    }

    if (entry.status === "error" && entry.error && !entry.sock) {
      throw new Error(entry.error);
    }

    await sleep(500);
  }

  if (entry.pairingCode) return entry.pairingCode;

  throw new Error(
    entry.error || "WhatsApp is still connecting. Please wait a few seconds and try again."
  );
}

export function getSession(id) {
  return sessions.get(id);
}

export function listSessions() {
  return [...sessions.values()].map((x) => ({
    id: x.id,
    phone: x.phone,
    status: x.status,
    pairingCode: x.pairingCode,
    error: x.error
  }));
}

export async function stopSession(id) {
  const entry = sessions.get(id);

  if (entry) {
    entry.shouldReconnect = false;
    try {
      entry.sock?.end(undefined);
    } catch {}
    sessions.delete(id);
    await Session.findOneAndUpdate(
      { sessionId: id },
      { status: "stopped" }
    );
  } else {
    await Session.findOneAndUpdate(
      { sessionId: id },
      { status: "stopped" }
    );
  }
}

export async function deleteSession(id) {
  await stopSession(id);
  fs.rmSync(path.join(config.storage.sessionsDir, id), {
    recursive: true,
    force: true
  });
  await Session.deleteOne({ sessionId: id });
}

export async function startSavedSessions() {
  const dirs = fs.readdirSync(config.storage.sessionsDir, {
    withFileTypes: true
  });

  for (const dir of dirs.filter((x) => x.isDirectory())) {
    startSession(dir.name)
      .then((entry) => {
        entry.attachBot = attachBot;
        attachBot(entry);
      })
      .catch((error) => {
        console.error(`[SESSION:${dir.name}] Startup failed:`, error.message);
      });
  }
}
